import datetime

class Usuario:
    def __init__(self, correo, nombre_comercio, telefono_comercio, nombre_dueno, ubicacion_local):
        self.correo = correo
        self.nombre_comercio = nombre_comercio
        self.telefono_comercio = telefono_comercio
        self.nombre_dueno = nombre_dueno
        self.ubicacion_local = ubicacion_local

class FacturaElectronica:
    def __init__(self, tipo_cedula, numero_cedula, nombre, telefono, correo, provincia, canton, distrito):
        self.tipo_cedula = tipo_cedula
        self.numero_cedula = numero_cedula
        self.nombre = nombre
        self.telefono = telefono
        self.correo = correo
        self.provincia = provincia
        self.canton = canton
        self.distrito = distrito
###Ingresar datos de continuacion aqui


##Ingresar datos hasta aqui


# Registro de usuario
print("Bienvenido al sistema de registro de paquetes")
correo = input("Ingrese su correo electrónico: ")
nombre_comercio = input("Ingrese el nombre de su comercio: ")
telefono_comercio = input("Ingrese el teléfono de su comercio: ")
nombre_dueno = input("Ingrese su nombre: ")
ubicacion_local = input("Ingrese la ubicación de su local: ")
usuario = Usuario(correo, nombre_comercio, telefono_comercio, nombre_dueno, ubicacion_local)

# Registro de factura electrónica
tipo_cedula = input("Ingrese el tipo de cédula del destinatario: ")
numero_cedula = input("Ingrese el número de cédula del destinatario: ")
nombre = input("Ingrese el nombre del destinatario: ")
telefono = input("Ingrese el teléfono del destinatario: ")
correo = input("Ingrese el correo del destinatario: ")
provincia = input("Ingrese la provincia del destinatario: ")
canton = input("Ingrese el cantón del destinatario: ")
distrito = input("Ingrese el distrito: ")

